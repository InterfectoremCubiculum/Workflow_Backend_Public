﻿namespace WorkflowTime.Configuration
{
    public class AppFrontendUrlOptions
    {
        public required string Url { get; set; }
    }
}
