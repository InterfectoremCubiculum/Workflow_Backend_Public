﻿namespace WorkflowTime.Configuration
{
    public class TeamsOptions
    {
        public required string TeamId { get; set; }
        public required string ChannelId { get; set; }
    }
}
