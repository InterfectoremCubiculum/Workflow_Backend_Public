﻿namespace WorkflowTime.Enums
{
    public enum AnomalyType
    {
        TooLongBreak,
        LateLogin,
        LongWorkSession,
        NoBreaks,
        SpentTooMuchTimeOnBreak,
    }
}
