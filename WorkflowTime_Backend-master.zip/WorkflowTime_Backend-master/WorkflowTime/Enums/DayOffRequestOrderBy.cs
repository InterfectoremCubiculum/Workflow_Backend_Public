﻿namespace WorkflowTime.Enums
{
    public enum DayOffRequestOrderBy
    {
        StartDate,
        EndDate,
        RequestDate
    }
}
