﻿namespace WorkflowTime.Enums
{
    public enum ResolveActionCommand
    {
        Reject,
        Approve,
        SetStartTimeAsCreationDate,
    }
}
