﻿namespace WorkflowTime.Enums
{
    public enum SettingsType
    {
        String,
        Integer,
        Decimal,
        Boolean,
        DateTime,
        TimeSpan,
    }
}
