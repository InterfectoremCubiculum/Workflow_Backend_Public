﻿namespace WorkflowTime.Enums
{
    public enum TimeSegmentType
    {
        Work,
        Break
    }
}
