﻿namespace WorkflowTime.Enums
{
    public enum UserRole
    {
        None,
        Admin,
        User,
    }
}
