﻿namespace WorkflowTime.Exceptions
{
    public class BadRequestException(string message) : Exception(message)
    {
    }
}
