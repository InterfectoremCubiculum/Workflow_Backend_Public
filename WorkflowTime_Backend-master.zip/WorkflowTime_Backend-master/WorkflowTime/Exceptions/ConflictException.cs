﻿namespace WorkflowTime.Exceptions
{
    public class ConflictException(string message) : Exception(message)
    {
    }
}
