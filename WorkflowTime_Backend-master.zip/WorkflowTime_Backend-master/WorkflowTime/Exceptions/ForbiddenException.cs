﻿namespace WorkflowTime.Exceptions
{
    public class ForbiddenException(string message) : Exception(message)
    {
    }
}
