﻿namespace WorkflowTime.Exceptions
{
    public class NotFoundException(string message) : Exception(message)
    {
    }
}
