﻿namespace WorkflowTime.Features.ProjectManagement.Dtos
{
    public class CreateProjectDto
    {
        public required string Name { get; set; }
    }
}
