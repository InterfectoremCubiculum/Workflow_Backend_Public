﻿namespace WorkflowTime.Features.ProjectManagement.Dtos
{
    public class GetSearchedProjectDto
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}
