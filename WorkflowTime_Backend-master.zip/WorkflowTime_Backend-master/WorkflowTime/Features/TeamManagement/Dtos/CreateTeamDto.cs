﻿namespace WorkflowTime.Features.TeamManagement.Dtos
{
    public class CreateTeamDto
    {
        public required string Name { get; set; }
    }
}
