﻿namespace WorkflowTime.Features.TeamManagement.Dtos
{
    public class GetSearchedTeamDto
    {
        public int Id { get; set; }
        public required string Name { get; set; }
    }
}
