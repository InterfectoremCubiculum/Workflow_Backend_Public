﻿namespace WorkflowTime.Features.UserManagement.Queries
{
    public class UserSearchQueryParameters
    {
        public string SearchingPhrase { get; set; }
        public int ResponseLimit { get; set; }
    }
}
