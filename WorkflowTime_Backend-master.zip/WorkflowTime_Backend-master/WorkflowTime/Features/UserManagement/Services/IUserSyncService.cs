﻿namespace WorkflowTime.Features.UserManagement.Services
{
    public interface IUserSyncService
    {
        Task Sync();
    }
}
